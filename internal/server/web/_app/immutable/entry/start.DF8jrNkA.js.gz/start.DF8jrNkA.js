import{l as o,a as r}from"../chunks/CbEvW4AZ.js";export{o as load_css,r as start};
