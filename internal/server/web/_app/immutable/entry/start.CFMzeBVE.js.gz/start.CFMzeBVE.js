import{l as o,a as r}from"../chunks/Br36cv6X.js";export{o as load_css,r as start};
