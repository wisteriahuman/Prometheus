import{l as o,a as r}from"../chunks/BiR-QHxJ.js";export{o as load_css,r as start};
