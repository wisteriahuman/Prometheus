import{l as o,a as r}from"../chunks/BTzNBLdh.js";export{o as load_css,r as start};
