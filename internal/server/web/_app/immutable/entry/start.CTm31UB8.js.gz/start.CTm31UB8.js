import{l as o,a as r}from"../chunks/C_SNf7_W.js";export{o as load_css,r as start};
