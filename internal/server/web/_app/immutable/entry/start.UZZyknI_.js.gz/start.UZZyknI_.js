import{l as o,a as r}from"../chunks/Ck85ZoEL.js";export{o as load_css,r as start};
